from pyspark.sql import SparkSession
from pyspark.sql.functions import count

spark = SparkSession. \
    builder. \
    master('local'). \
    appName('EMR tutorial'). \
    getOrCreate()

df = spark.read.parquet('../../data/itv-github/raw/ghactivity')
df.select('created_at','year','month','day')
df.groupBy('year','month','day').agg(count('*').alias('total_count')).show()
df.count()
